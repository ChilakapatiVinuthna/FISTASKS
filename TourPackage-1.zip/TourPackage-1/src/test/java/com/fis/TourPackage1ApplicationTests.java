package com.fis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourPackage1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

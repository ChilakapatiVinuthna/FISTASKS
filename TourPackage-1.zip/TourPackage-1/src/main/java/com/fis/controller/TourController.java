package com.fis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.entity.Tour;
import com.fis.service.ServiceTour;

import java.util.*;

@RestController
public class TourController {

	@Autowired
	ServiceTour servicetour;
	@GetMapping("/Tourpackage")
	public ResponseEntity<List<Tour>> getAllt()
	{
		return new ResponseEntity<>(servicetour.getAll(), HttpStatus.OK);
	}
	@GetMapping("/Tourpackage/{tourId}")
	public ResponseEntity<Tour> get(@PathVariable("tourId") String tourPackId)
	{
		return new ResponseEntity<>(servicetour.get(tourPackId), HttpStatus.OK);
	}
	@GetMapping("/Tourpackage/{tourId}/cost/{numdays}")
	public ResponseEntity<Double> get(@PathVariable("tourId") String tourPackId,@PathVariable("numdays") int numdays)
	{
		return new ResponseEntity<>(servicetour.calculateamt(tourPackId,numdays), HttpStatus.OK);
	}
	@GetMapping("/Tourpackage/source/{source}/destination/{destination}/cost/{numdays}")
	public ResponseEntity<Double> get(@PathVariable("source") String source,@PathVariable("destination") String destination, @PathVariable("numdays") int numdays)
	{
		return new ResponseEntity<>(servicetour.calculateAmtByFillter(source,destination, numdays), HttpStatus.OK);
	}

	@PostMapping("/Tourpackage")
	public ResponseEntity<Tour> get(@RequestBody Tour tour) 
	{
		return new ResponseEntity<>(servicetour.create(tour), HttpStatus.CREATED);
	}

}
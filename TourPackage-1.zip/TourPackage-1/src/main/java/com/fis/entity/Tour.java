package com.fis.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Tour {
	@Id

	@Column(length =7,nullable =false,unique=true)
	private String package_id;
	@Column(nullable =false)
	private String sourcePlace;
	@Column(nullable =false)
	private int fare;
	@Column(nullable =false)
	private String destinationPlace;
	public String getPackage_id() {
		return package_id;
	}
	public void setPackage_id(String package_id) {
		this.package_id = package_id;
	}
	public String getSource_place() {
		return sourcePlace;
	}
	public void setSource_place(String source_place) {
		this.sourcePlace = source_place;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public String getDestination_place() {
		return destinationPlace;
	}
	public void setDestination_place(String destination_place) {
		this.destinationPlace = destination_place;
	}
	
	public Tour(String package_id, String source_place, int fare, String destination_place) {
		super();
		this.package_id = package_id;
		this.sourcePlace = source_place;
		this.fare = fare;
		this.destinationPlace = destination_place;
	}
	public Tour() {
		super();
		// TODO Auto-generated constructor stub
	}

}

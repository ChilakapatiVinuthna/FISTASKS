package com.fis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fis.db.Datatour;
import com.fis.entity.Tour;

import java.util.*;
@Component
public class ServiceTour {
	@Autowired
	Datatour datatour;
	private static final int GST = 12;
	public Tour create(Tour tour) {
		return datatour.save(tour);
	}
	public Tour get(String tourId) {
		return datatour.findById(tourId).orElseThrow(() -> new RuntimeException("No tour id:" +tourId));
	}

	public double calculateamt(String packageid, int numdays) {
		Tour tour = get(packageid);
		return getCostForTour(numdays, tour);

	}
	private double getCostForTour(int numdays, Tour tour) {
		double packagefare = tour.getFare() * numdays;
		double discountfare = packagefare - (packagefare * getDiscount(numdays) / 100);
		double totalcost = discountfare + (discountfare * GST / 100);
		return totalcost;
	}

	public int getDiscount(int numdays) {
		int discount = 0;
		if (numdays > 5 && numdays <= 8) {
			discount = 3;
		} else if (numdays > 8 && numdays <= 10) {
			discount = 5;
		} else if (numdays > 10) {
			discount = 7;
		}
		return discount;
	}
	public List<Tour> getAll(){
		return datatour.findAll();
	}
	public Double  calculateAmtByFillter(String source, String destination, int numdays) {
		Tour tourFromDb = datatour.findBySourcePlaceAndDestinationPlace(source, destination);
		
		return getCostForTour(numdays, tourFromDb);
	}

}

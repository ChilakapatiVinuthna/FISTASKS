package com.fis.db;



import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.entity.Tour;

public interface Datatour extends JpaRepository <Tour,String> {

	public Tour findBySourcePlaceAndDestinationPlace(String source, String destination);
	
}

